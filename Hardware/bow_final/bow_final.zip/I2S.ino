void i2sInit() {
  i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = I2S_SAMPLE_RATE,
    .bits_per_sample = i2s_bits_per_sample_t(I2S_SAMPLE_BITS),
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = i2s_comm_format_t(I2S_COMM_FORMAT_I2S | I2S_COMM_FORMAT_I2S_MSB),
    .intr_alloc_flags = 0,
    .dma_buf_count = 16,
    .dma_buf_len = 256,
    .use_apll = 1
  };

  i2s_driver_install(I2S_PORT, &i2s_config, 0, NULL);

  const i2s_pin_config_t pin_config = {
    .bck_io_num = I2S_SCK,
    .ws_io_num = I2S_WS,
    .data_out_num = -1,
    .data_in_num = I2S_SD
  };

  i2s_set_pin(I2S_PORT, &pin_config);
}

void example_disp_buff(uint8_t* buf, int length)
{
  printf("======\n");
  for (int i = 0; i < length; i++) {
    printf("%02x ", buf[i]);
    if ((i + 1) % 8 == 0) {
      printf("\n");
    }
  }
  printf("======\n");
}


void i2s_adc_data_scale(uint8_t * d_buff, uint8_t* s_buff, uint32_t len)
{
  uint32_t j = 0;
  uint32_t dac_value = 0;
  for (int i = 0; i < len; i += 2) {

    dac_value = ((((uint16_t) (s_buff[i + 1] & 0xf) << 8) | ((s_buff[i + 0]))));
    d_buff[j++] = dac_value * 256 / 2048;
  }
}

int16_t calculateRMS(const int16_t* buff, int len) {
  int64_t sum = 0;
  for (int i = 0; i < len; i++) {
    int16_t sample = buff[i];
    sum += (int64_t)sample * sample;
  }
  return (int16_t)sqrt(sum / len);
}

void i2s_adc(void *arg)
{
  static JsonDocument bowBatteryDoc;
  static char bowBatBuffer[16];
  //    int flash_wr_size = 0;
  size_t bytes_read;
  int silence_count = 0;
  bool is_recording = false;
  //  uint8_t payload[i2s_read_len + 4];
  uint32_t audio_seq = 0;
  char* i2s_read_buff = (char*) calloc(I2S_READ_LEN, sizeof(char));
  //  uint8_t* flash_write_buff = (uint8_t*) calloc(i2s_read_len, sizeof(char));
  static long beforeProcessing = 0;

  // Discard first two reads to let the mic stabilise
  i2s_read(I2S_PORT, (void*) i2s_read_buff, I2S_READ_LEN, &bytes_read, portMAX_DELAY);
  i2s_read(I2S_PORT, (void*) i2s_read_buff, I2S_READ_LEN, &bytes_read, portMAX_DELAY);

  Serial.println(" *** VAD Listening *** ");

  while (true) {
    if (uxQueueSpacesAvailable(audioQueue) > 0) {
      AudioFrame* frame = &audioBuffer[audioBufferHead];
      i2s_read(I2S_PORT, frame->pcm, I2S_READ_LEN, &bytes_read, portMAX_DELAY);

      //    i2s_read(I2S_PORT, (void*) i2s_read_buff, i2s_read_len, &bytes_read, portMAX_DELAY);
      //      int16_t* i2sReadPointer = audioBuffer + (audioBufferHead * AUDIO_BUFFER_SIZE) + AUDIO_HEADER_SIZE;
      //      i2s_read(I2S_PORT, i2sReadPointer, I2S_READ_LEN, &bytes_read, portMAX_DELAY);
      //      for (int i = 0; i<64; i++){
      //        Serial.print(i2sReadPointer[i]);
      //        Serial.print(" ");
      //      }
      //      Serial.println();
      //    beforeProcessing = micros();
      //    i2s_adc_data_scale(flash_write_buff, (uint8_t*)i2s_read_buff, i2s_read_len);
      //      i2s_adc_data_scale(i2sReadPointer, (uint8_t*)i2s_read_buff, I2S_READ_LEN);

      //    int16_t rms = calculateRMS(flash_write_buff, i2s_read_len);
      //      int16_t rms = calculateRMS(i2sReadPointer, AUDIO_BUFFER_SIZE);
      int16_t rms = calculateRMS(frame->pcm, bytes_read / sizeof(int16_t));

      printf("RMS: %d\n", rms);

      if (rms > VAD_THRESHOLD) {
        if (!is_recording) {
          Serial.println(" *** Voice detected - recording *** ");
          is_recording = true;
        }
        //      memcpy(payload, &audio_seq, 4);
        //      memcpy(payload + 4, &flash_write_buff, i2s_read_len);
        //      memcpy(i2sReadPointer - AUDIO_HEADER_SIZE, &audio_seq, 4);
        //        memcpy(i2sReadPointer - AUDIO_HEADER_SIZE, &audio_seq, AUDIO_HEADER_SIZE);
        //        xQueueSend(audioQueue, &audioBufferHead, 0);
        //        audioBufferHead = ( audioBufferHead + 1 ) % BUFFER_LEN;
        frame->sequence = audio_seq;
        xQueueSend(audioQueue, &audioBufferHead, 0);
        audioBufferHead = (audioBufferHead + 1) % BUFFER_LEN;
        audio_seq++;
        silence_count = 0;

        //            esp_mqtt_client_enqueue(mqtt_client, "sensor/audio", (const char*)payload, i2s_read_len+4, 0, 0, true);
        //      esp_mqtt_client_publish(mqtt_client, "sensor/audio", (const char*)payload, i2s_read_len + 4, 0, 0);
        //      example_disp_buff(flash_write_buff, 64);
        //      Serial.print("unused space in i2s: ");
        //      Serial.println(uxTaskGetStackHighWaterMark(NULL));
      }
      else if (is_recording) {
        silence_count++;
        //        example_disp_buff(flash_write_buff, 64);
        //        memcpy(payload, &audio_seq, 4);
        //        memcpy(payload + 4, flash_write_buff, i2s_read_len);
        //        memcpy(i2sReadPointer - AUDIO_HEADER_SIZE, &audio_seq, 4);
        frame->sequence = audio_seq;
        xQueueSend(audioQueue, &audioBufferHead, 0);
        audioBufferHead = ( audioBufferHead + 1 ) % BUFFER_LEN;
        audio_seq++;
      }

      //        Serial.print("unused space in i2s: ");
      //        Serial.println(uxTaskGetStackHighWaterMaMrk(NULL));
      //        esp_mqtt_client_enqueue(mqtt_client, "sensor/audio", (const char*)payload, i2s_read_len+4, 0, 0, true);
      //        esp_mqtt_client_publish(mqtt_client, "sensor/audio", (const char*)payload, i2s_read_len + 4, 0, 0);

      if (silence_count >= VAD_SILENCE_LIMIT) {
        Serial.println(" *** Silence detected - pausing *** ");
        is_recording = false;
        silence_count = 0;
      }
    }
    else {
      Serial.println("audio queue full");
    }

    nowI2S = millis();
    if (nowI2S - lastBatTime > 5000) {
      //      Serial.println(adc1_get_raw(ADC1_CHANNEL_0));
      bowBatteryDoc.clear();
      bowBatteryDoc["value"] = adc1_get_raw(ADC1_CHANNEL_0);

      serializeJson(bowBatteryDoc, bowBatBuffer);
      xQueueSend(batteryQueue, bowBatBuffer, 0);
      //      esp_mqtt_client_enqueue(mqtt_client, "sensor/bowBattery", bowBatBuffer, 0, 0, 0, true);
      lastBatTime = nowI2S;
    }
  }
}
