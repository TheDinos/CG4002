void publisher(void *arg) {
//  char audio_buf[I2S_READ_LEN + 4];
  uint8_t audioIndex = 0;
  while (true) {
    // Blocks here waiting for data, not inside MQTT internals

    if (xQueueReceive(audioQueue, &audioIndex, (5000/portTICK_PERIOD_MS)) == pdTRUE) {
//      int16_t *publishPointer = audioBuffer + audioIndex * AUDIO_BUFFER_SIZE;
      AudioFrame *publishFrame = &audioBuffer[audioIndex];
      esp_mqtt_client_publish(mqtt_client, "sensor/audio", (char *)publishFrame, sizeof(AudioFrame), 0, 0);

//      esp_mqtt_client_publish(mqtt_client, "sensor/audio", (char *)publishPointer, AUDIO_BUFFER_SIZE, 0, 0);
      Serial.println("publishing audio");
    }
 vTaskDelay(pdMS_TO_TICKS(2));
  }
}
